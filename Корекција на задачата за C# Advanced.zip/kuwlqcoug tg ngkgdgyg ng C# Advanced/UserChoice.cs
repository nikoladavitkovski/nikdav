﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.CSharpAdvanced.Class01.ConsoleApp3
{
    public enum UserChoice
    {
        Rock=1,
        Paper=2,
        Scissors=3
    }
}
