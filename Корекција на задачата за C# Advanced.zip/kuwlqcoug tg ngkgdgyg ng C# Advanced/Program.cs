﻿using System;
public delegate void PropertyChanger(string playerOne, string PlayerTwo);
namespace SEDC.CSharpAdvanced.Class01.ConsoleApp3
{
    class TestDelegate
    {
        public static int ChooseMenuItem(string userInput)
        {
            int result = 0;
            bool isValidNumber = int.TryParse(userInput, out result);
            return result;
        }
        public static void Play(Player playerOne, Player playerTwo)
        {
            int playerOnePickRandom = new Random().Next(1, 3);
            playerOne.PlayerChoice = (UserChoice)playerOnePickRandom;
            int playerTwoPickRandom = new Random().Next(1, 3);
            playerTwo.PlayerChoice = (UserChoice)playerTwoPickRandom;
            string resultText = DecideWinner(playerOne, playerTwo);
            Console.WriteLine(resultText);
        }

        public static string DecideWinner(Player playerOne, Player playerTwo)
        {
            if (playerOne.PlayerChoice == UserChoice.Rock && playerTwo.PlayerChoice == UserChoice.Scissors)
            {
                playerOne.Score++;
                return $"Player {playerOne.Name} won";
            }
            if (playerOne.PlayerChoice == UserChoice.Rock && playerTwo.PlayerChoice == UserChoice.Paper)
            {
                playerTwo.Score++;
                return $"Player {playerTwo.Name} won";
            }
            if (playerOne.PlayerChoice == UserChoice.Scissors && playerTwo.PlayerChoice == UserChoice.Paper)
            {
                playerOne.Score++;
                return $"Player {playerOne.Name} won";
            }
            if (playerOne.PlayerChoice == UserChoice.Scissors && playerTwo.PlayerChoice == UserChoice.Rock)
            {
                playerTwo.Score++;
                return $"Player {playerTwo.Name} won";
            }
            if (playerOne.PlayerChoice == UserChoice.Paper && playerTwo.PlayerChoice == UserChoice.Rock)
            {
                playerOne.Score++;
                return $"Player {playerOne.Name} won";
            }
            else
            {
                return "It's a tie";
            }
        }
        public static void DisplayStats(Player playerOne, Player playerTwo, int matchesPlayed)
        {
            Console.WriteLine($"The player {playerOne.Name} has {playerOne.Score} wins");
            Console.WriteLine($"The player {playerTwo.Name} has {playerTwo.Score} wins");
            double playerOneWins = (double)playerOne.Score / (double)matchesPlayed;
            double playerTwoWins = (double)playerTwo.Score / (double)matchesPlayed;
            Console.WriteLine(string.Format("The player {0} has {1:P} wins", playerOne.Name, playerOneWins));
            Console.WriteLine(string.Format("The player {0} has {1:P} wins", playerTwo.Name, playerTwoWins));
        }
        public static void Exit()
        {
            Exit();
        }
        static void Main(string[] args)
        {
            TestDelegate testDelegate = new TestDelegate();
            TestDelegate.ChooseMenuItem("Damjan");
            int matchesPlayed = 0;
            Player damjan = new Player() { Name = "Damjan" };
            Player petre = new Player() { Name = "Petre" };

            //if(menuChosen == 0)
            //{
            //throw new Exception("The user input must be a number and not zero");
            //} else if(menuChosen == 1)
            //{
            //TODO: Should play the game
            //} else if(menuChosen == 2)
            //{
            //TODO: Should show
            //} else
            //{
            //Exit the application
            //}
            while (true)
            {
                Console.WriteLine("Please enter 1 to play 2 for stats and 3 to exit");
                string userInput = Console.ReadLine();
                int menuChosen = ChooseMenuItem(userInput);
                switch (menuChosen)
                {
                    case 0:
                        throw new Exception("Wrong input");
                        break;
                    case 1:
                        Play(damjan, petre);
                        matchesPlayed++;
                        break;
                    case 2:
                        DisplayStats(damjan, petre, matchesPlayed);
                        break;
                    default:
                        //Close the app
                        break;
                }
                if (menuChosen != 1)
                {
                    break;
                }
            }
            Console.ReadLine();
        }        
    }
}
