﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.CSharpAdvanced.Class01.ConsoleApp3
{
   public class Player
    {
        public string Name { get; set; }

        public int Score { get; set; }

        public UserChoice PlayerChoice { get; set; }
    }
}
